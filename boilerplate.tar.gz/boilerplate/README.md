# Backend with flask Boilerplate

The directory structure is given in `structure.txt`.

You need to create `app.db` in the current directory.
Just run `touch app.db`.

